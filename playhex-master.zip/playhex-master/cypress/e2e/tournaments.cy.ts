const randomString = (): string => (1E24 * Math.random()).toString(36);
const tournamentSlug = (tournamentTitle: string): string => tournamentTitle.toLocaleLowerCase().replace(/ /g, '-');

describe('Tournaments', () => {
    it('can create, check-in, and edit a tournament', () => {
        cy.visit('/');
        cy.get('.menu-top').contains('Tournaments').click();

        // Create tournament
        cy.contains('Create tournament').click();

        const tournamentTitle = 'Tournament test ' + randomString();

        cy
            .contains('Tournament name')
            .click()
            .type(tournamentTitle)
        ;

        cy
            .contains('Double elimination')
            .click()
        ;

        cy
            .contains('Start date')
            .click()
            .type('2025-01-02T20:30')
        ;

        cy
            .contains('button', 'Create tournament')
            .click()
        ;

        cy.contains('Tournament created successfully');
        cy.url().should('include', '/tournaments/' + tournamentSlug(tournamentTitle));
        cy.contains('h1', tournamentTitle);

        cy.get('h5').contains('Thursday, January 2, 2025 at 8:30 PM');
        cy.contains('Imminent!');

        cy.get('h5').contains('Double elimination');
        cy.contains('11×11');

        // Check-in
        cy.contains('0 participants');
        cy.contains('Check-in now to play this tournament!');
        cy.contains('button', 'Check-in').click();
        cy.contains('1 participant');
        cy.contains('Your participation is confirmed!');

        // Checking-in prompts to enable notifications, dismiss it
        cy.contains('.modal', 'Enable notifications?').contains('button', 'Ignore').click();
        cy.get('.modal').should('not.exist');

        // Unsubscribe
        cy.contains('I am no longer interested').click();
        cy.contains('0 participants');
        cy.contains('Check-in now to play this tournament!');

        // Change tournament format to Swiss
        cy.contains('Manage').click();

        cy
            .contains('Swiss')
            .click()
        ;

        cy
            .contains('button', 'Submit modification')
            .click()
        ;

        cy.contains('Tournament updated successfully');
        cy.contains('h5', 'Swiss');
        cy.contains('Rounds: based on participants number');

        // Change tournament start delay
        cy.contains('Tournament will start automatically');
        cy.contains('Manage').click();

        cy
            .contains('Never')
            .click()
        ;

        cy
            .contains('button', 'Submit modification')
            .click()
        ;

        cy.contains('Tournament updated successfully');
        cy.contains('Tournament will be started manually by organizer only.');

        // Change tournament title: I should be redirected to new url (slug changed)
        cy.contains('Manage').click();

        const tournamentTitle2 = 'Tournament edited ' + randomString();

        cy
            .contains('Tournament name')
            .click()
            .type(tournamentTitle2)
        ;

        cy
            .contains('button', 'Submit modification')
            .click()
        ;

        cy.contains('Tournament updated successfully');
        cy.url().should('include', '/tournaments/' + tournamentSlug(tournamentTitle2));
        cy.contains('h1', tournamentTitle2);
    });

    it('keeps cloned tournament time control selected, even if it is not a player preset', () => {
        cy.visit('/tournaments/create');

        const tournamentTitle = 'Tournament clone tc ' + randomString();

        cy
            .contains('Tournament name')
            .click()
            .type(tournamentTitle)
        ;

        cy
            .contains('Start date')
            .click()
            .type('2025-01-02T20:30')
        ;

        // Use a custom time control, i.e not one of the default presets
        cy.slidePrimaryTimeControl(5, 'min');
        cy.slideSecondaryTimeControl(30, 's');

        cy.contains('button', '5min + 30s').should('have.class', 'btn-success');

        cy
            .contains('button', 'Create tournament')
            .click()
        ;

        cy.contains('Tournament created successfully');

        // Tournament page can take a few seconds to show up after creation
        cy.contains('h1', tournamentTitle, { timeout: 20000 });

        // Clone this tournament
        cy.contains('a', 'Clone').click();

        cy.url().should('include', 'clone=' + tournamentSlug(tournamentTitle));

        // Cloned time control must be displayed as an already selected preset button,
        // without having to touch the sliders first
        cy.contains('Initial time: 5min');
        cy.contains('button', '5min + 30s').should('have.class', 'btn-success');
    });
});
