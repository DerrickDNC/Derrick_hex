// ***********************************************************
// This example support/e2e.ts is processed and
// loaded automatically before your test files.
//
// This is a great place to put global configuration and
// behavior that modifies Cypress.
//
// You can change the location of this file or turn off
// automatically serving support files with the
// 'supportFile' configuration option.
//
// You can read more here:
// https://on.cypress.io/configuration
// ***********************************************************

// Import commands.js using ES2015 syntax:
import 'reflect-metadata';
import './commands.js';

// Ignore errors when a request fails because we .reload() or a test ends and request is aborted
Cypress.on('uncaught:exception', (e): false | void => {
    if (
        Cypress.browser.name === 'firefox' &&
        (e.name === 'AbortError' || e.message.includes('AbortError') ||e.message.includes('NetworkError') || e.message.includes('error loading dynamically imported module'))
    ) {
        return false;
    }
});
