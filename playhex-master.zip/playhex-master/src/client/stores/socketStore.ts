import { io, Socket } from 'socket.io-client';
import { HexClientToServerEvents, HexServerToClientEvents } from '../../shared/app/HexSocketEvents.js';
import * as CustomParser from '../../shared/app/socketCustomParser.js';
import { defineStore } from 'pinia';
import useAuthStore from './authStore.js';
import { watch, ref } from 'vue';
import Rooms from '../../shared/app/Rooms.js';
import { WebsocketActionError } from '../../shared/app/Types.js';
import { showToastFromRateLimitPayload } from '../services/rate-limiter.js';
import useToastsStore from './toastsStore.js';
import { t } from 'i18next';

/**
 * Use global io if overriden, else use normal io.
 * Used for functionnal tests, to allow using a mocked io.
 */
const getIo = (): typeof io => {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    return ((window as any).io ?? io);
};

const useSocketStore = defineStore('socketStore', () => {
    const socket: Socket<HexServerToClientEvents, HexClientToServerEvents> = getIo()({
        parser: CustomParser,
        autoConnect: false, // connect once player is logged in at least as guest
    });

    const joinRoom = (room: string) => new Promise<void>(resolve => {
        socket.emit('joinRoom', room, () => resolve());
    });

    const leaveRoom = (room: string) => socket.emit('leaveRoom', room);

    const connected = ref(false);

    /*
     * Reconnect socket when logged in player changed
     */
    const reconnectSocket = (): void => {
        socket.disconnect().connect();
    };

    const authStore = useAuthStore();

    watch(() => authStore.loggedInPlayer, player => {
        if (player === null) {
            socket.disconnect();
            return;
        }

        reconnectSocket();
        void joinRoom(Rooms.player(player.publicId));
    });

    socket.on('connect', () => {
        connected.value = true;
    });

    socket.on('disconnect', () => {
        connected.value = false;
    });

    const handleMessageError = (error: WebsocketActionError, unhandledErrorMessage = 'server error') => {
        if (error.reason === 'rate_limited') {
            showToastFromRateLimitPayload(error.payload);
            return;
        }

        if (error.reason === 'client_error') {
            useToastsStore().addToast(t(error.payload.translationKey), { level: 'danger' });
            return;
        }

        useToastsStore().addToast(unhandledErrorMessage, { level: 'danger' });
    };

    return {
        socket,
        connected,
        joinRoom,
        leaveRoom,
        reconnectSocket,
        handleMessageError,
    };
});

export default useSocketStore;
