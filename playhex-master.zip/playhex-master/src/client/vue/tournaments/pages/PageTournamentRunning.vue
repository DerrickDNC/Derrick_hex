<script setup lang="ts">
import AppTournamentBracket from '../components/AppTournamentBracket.vue';
import { useHead } from '@unhead/vue';
import { useTournamentFromUrl } from '../composables/tournamentFromUrl.js';
import AppBreadcrumb from '../../components/AppBreadcrumb.vue';
import { tournamentBreadcrumb } from '../composables/tournamentBreadcrumb.js';
import AppTournamentHistorySection from '../components/AppTournamentHistorySection.vue';
import AppTournamentStandings from '../components/AppTournamentStandings.vue';
import AppTournamentFormat from '../components/AppTournamentFormat.vue';
import { IconRecordFill } from '../../icons.js';
import { getActiveTournamentMatches } from '../../../../shared/app/tournamentUtils.js';
import AppTournamentDescription from '../components/AppTournamentDescription.vue';
import AppTournamentOrganizerAndAdmins from '../components/AppTournamentOrganizerAndAdmins.vue';
import AppSeedingInfo from '../components/AppSeedingInfo.vue';
import AppTournamentExplorationAllowedInfo from '../components/AppTournamentExplorationAllowedInfo.vue';
import AppChannel from '../../components/AppChannel.vue';

const {
    tournament,
    slug,
    iAmHost,
} = useTournamentFromUrl();

useHead({
    title: () => tournament.value ? tournament.value.title : 'Tournament',
});
</script>

<template>
    <template v-if="tournament">
        <div class="container-fluid my-3">
            <AppBreadcrumb :items="tournamentBreadcrumb(tournament)" />

            <router-link
                v-if="iAmHost()"
                :to="{ name: 'tournament-manage', params: { slug } }"
                class="btn btn-sm btn-outline-warning float-end ms-2"
            >
                {{ $t('manage_tournament') }}
            </router-link>

            <router-link
                :to="{ name: 'tournaments-create', query: { clone: slug } }"
                class="btn btn-sm btn-outline-success float-end ms-2"
            >
                {{ $t('clone_tournament') }}
            </router-link>

            <h1 class="m-0">{{ tournament.title }}</h1>

            <AppTournamentOrganizerAndAdmins :tournament />

            <AppTournamentFormat :tournament />

            <AppTournamentExplorationAllowedInfo :tournament />

            <p class="lead">
                <IconRecordFill class="text-danger" />
                {{ $t('n_playing_games', { count: getActiveTournamentMatches(tournament).length }) }}
            </p>
        </div>

        <AppTournamentBracket :tournament />

        <div class="container-fluid my-3">
            <p>
                <AppSeedingInfo :tournament />
            </p>
        </div>

        <div class="container-fluid my-3">
            <AppTournamentStandings :tournament />

            <AppTournamentDescription :tournament />

            <div class="row">
                <div class="col-md-6">
                    <AppChannel :channels="'tournament-' + tournament.slug" class="mb-3" />
                </div>
                <div class="col-md-6">
                    <AppTournamentHistorySection :tournament />
                </div>
            </div>
        </div>
    </template>
</template>
